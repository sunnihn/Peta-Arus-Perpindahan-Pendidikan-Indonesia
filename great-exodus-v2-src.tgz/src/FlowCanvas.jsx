import { useEffect, useRef, useState } from 'react'
import { feats, allFlows, travellers, bez, vmax, W, H } from './model'
import { statBy, stats, valueOf, rankMap, nf, nfs } from './derived'
import { drawSprite } from './sprites'

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))
const land = feats.map((f) => ({ ...f, path: new Path2D(f.d) }))
const cOf = Object.fromEntries(land.map((l) => [l.key, l.c]))
const lerp = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t))
const C0 = [18, 58, 115], C_POS = [70, 150, 235], C_NEG = [190, 210, 235]

function hitFlow(wx, wy, tol, list) {
  let best = null, bd = tol
  for (const f of list) for (const s of f.strands) {
    const p = s.pts
    for (let i = 0; i < p.length - 1; i++) {
      const vx = p[i + 1][0] - p[i][0], vy = p[i + 1][1] - p[i][1], l2 = vx * vx + vy * vy || 1
      const u = clamp(((wx - p[i][0]) * vx + (wy - p[i][1]) * vy) / l2, 0, 1)
      const d = Math.hypot(wx - (p[i][0] + u * vx), wy - (p[i][1] + u * vy))
      if (d < bd) { bd = d; best = f }
    }
  }
  return best
}

export function activeFlows(sel, mode, topN) {
  let l = allFlows
  if (sel) l = l.filter((f) => (mode === 'origin' ? f.from === sel : mode === 'dest' ? f.to === sel : f.from === sel || f.to === sel))
  return topN === 'all' ? l : l.slice(0, Number(topN))
}

export default function FlowCanvas({ ind, gender, mode, topN, sel, hoverKey, onSelect, onHover }) {
  const cv = useRef(null)
  const [tip, setTip] = useState(null)
  const P = useRef({}); P.current = { ind, gender, mode, topN, sel, hoverKey, onSelect, onHover }
  const view = useRef({ act: [], vals: {}, max: 1, rank: {}, conn: new Set() })
  const cam = useRef({ fit: () => {}, focus: () => {} })
  const st = useRef({ selFlow: null, hov: null, hovProv: null })

  // recompute derived view when controls change
  useEffect(() => {
    const vals = Object.fromEntries(stats.map((s) => [s.key, valueOf(s, ind, gender)]))
    const max = Math.max(...Object.values(vals).map(Math.abs)) || 1
    const act = activeFlows(sel, mode, topN)
    const conn = new Set(sel ? [sel] : [])
    if (sel) act.forEach((f) => { conn.add(f.from); conn.add(f.to) })
    view.current = { act, vals, max, rank: rankMap(ind, gender), conn, amax: act[0]?.v || vmax }
    st.current.selFlow = null
    sel ? cam.current.focus(cOf[sel], 1.2) : cam.current.fit()
  }, [ind, gender, mode, topN, sel])

  useEffect(() => {
    const canvas = cv.current, ctx = canvas.getContext('2d')
    let w = 0, h = 0, dpr = 1, raf = 0, last = performance.now(), clock = 0, fitK = 1, inited = false
    const tr = { k: 1, x: 0, y: 0 }, to = { k: 1, x: 0, y: 0 }
    let area = { cx: 0, cy: 0 }
    const set = (o) => Object.assign(to, o)
    const fitTo = () => ({ k: fitK, x: area.cx - (W / 2) * fitK, y: area.cy - (H / 2) * fitK })
    const focusTo = (c, rel) => { const k = fitK * rel; return { k, x: area.cx - c[0] * k, y: area.cy - c[1] * k } }
    cam.current = { fit: () => set(fitTo()), focus: (c, rel) => set(focusTo(c, rel)) }

    const resize = () => {
      const r = canvas.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio || 1)
      w = r.width; h = r.height; canvas.width = w * dpr; canvas.height = h * dpr
      const big = w > 900, rightPad = big ? 350 : 0, top = big ? 150 : 190, bottom = big ? 20 : 250
      fitK = Math.min((w - rightPad - 20) / W, (h - top - bottom) / H) * 0.98
      area = { cx: (w - rightPad) / 2, cy: top + (h - top - bottom) / 2 }
      const t = P.current.sel ? focusTo(cOf[P.current.sel], 1.2) : fitTo()
      if (!inited) { Object.assign(tr, t); inited = true }
      set(t)
    }
    resize(); window.addEventListener('resize', resize)

    const frame = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000); last = now; clock += dt
      const e = 1 - Math.exp(-dt * 4.2)
      tr.k = Math.exp(Math.log(tr.k) + (Math.log(to.k) - Math.log(tr.k)) * e)
      tr.x += (to.x - tr.x) * e; tr.y += (to.y - tr.y) * e
      const rel = tr.k / fitK, trav = clamp((2.6 - rel) / 1.1, 0, 1)
      const V = view.current, S = st.current, { sel, ind: I, hoverKey: hk } = P.current
      const hovP = S.hovProv || hk
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h)

      // ---- world layer
      ctx.save(); ctx.translate(tr.x, tr.y); ctx.scale(tr.k, tr.k)
      const px = (n) => n / tr.k
      ctx.lineJoin = 'round'
      for (const f of land) {
        const v = V.vals[f.key] ?? 0, t = Math.sqrt(Math.abs(v) / V.max)
        const col = lerp(C0, v < 0 ? C_NEG : C_POS, clamp(t * 0.95, 0, 1))
        const on = f.key === sel, hot = f.key === hovP, con = V.conn.has(f.key)
        ctx.fillStyle = `rgb(${col})`; ctx.globalAlpha = sel && !con ? 0.45 : 1; ctx.fill(f.path); ctx.globalAlpha = 1
        ctx.lineWidth = px(on || hot ? 1.8 : con ? 1.2 : 0.7)
        ctx.strokeStyle = on || hot ? '#fff' : con ? '#bfe0ff' : 'rgba(110,170,240,.75)'; ctx.stroke(f.path)
      }
      const crowd = clamp(Math.sqrt(40 / Math.max(V.act.length, 1)), 0.16, 1)
      const dim = (f) => crowd * (S.selFlow ? (f === S.selFlow ? 1 : 0.12) : S.hov ? (f === S.hov ? 1 / crowd : 0.45) : 1)
      ctx.globalCompositeOperation = 'lighter'
      for (const f of V.act) {
        const a = dim(f) * (0.22 + 0.7 * Math.sqrt(f.v / V.amax)), wd = 0.7 + 1.5 * Math.sqrt(f.v / vmax)
        ctx.lineWidth = px(f === S.hov || f === S.selFlow ? wd + 0.8 : wd)
        ctx.strokeStyle = f === S.hov || f === S.selFlow ? `rgba(255,255,255,${Math.min(1, a + 0.3)})` : `rgba(130,195,255,${a * 0.6})`
        for (const s of f.strands) ctx.stroke(s.path)
      }
      ctx.lineCap = 'round'
      for (const f of V.act) {
        const a = dim(f); if (a < 0.2) continue
        ctx.lineWidth = px(1.5); ctx.strokeStyle = `rgba(255,255,255,${0.7 * a})`
        for (const s of f.strands) {
          const u = (clock * s.sp + s.ph) % 1, i0 = Math.floor(u * 22), i1 = Math.min(23, i0 + 4)
          ctx.beginPath(); ctx.moveTo(s.pts[i0][0], s.pts[i0][1])
          for (let i = i0 + 1; i <= i1; i++) ctx.lineTo(s.pts[i][0], s.pts[i][1])
          ctx.stroke()
        }
      }
      ctx.globalCompositeOperation = 'source-over'
      // people + vehicles (largest flows only, fade in when zoomed out)
      const nTrav = Math.min(V.act.length, sel || S.selFlow ? 60 : 36)
      for (let q = 0; q < nTrav; q++) {
        const f = V.act[q], isSel = f === S.selFlow
        const a = (isSel ? 1 : trav) * (S.selFlow && !isSel ? 0.4 : 1); if (a < 0.03) continue
        for (const m of travellers(f)) {
          m.t += m.v * dt; if (m.t > 1.08) m.t = -0.08
          if (m.t < 0 || m.t > 1) continue
          const [x, y] = bez(m.s.p0, m.s.c, m.s.p2, m.t), [x2, y2] = bez(m.s.p0, m.s.c, m.s.p2, Math.min(1, m.t + 0.02))
          const size = (m.type === 'plane' ? 26 : m.type === 'student' ? 20 : 21) * Math.pow(Math.max(rel, 0.6), 0.38)
          ctx.save(); ctx.globalAlpha = a * Math.min(1, m.t * 14, (1 - m.t) * 14)
          ctx.translate(x, y); ctx.scale(size / 24 / tr.k, size / 24 / tr.k)
          drawSprite(ctx, m.type, clock + m.seed, x2 - x, y2 - y); ctx.restore()
        }
      }
      ctx.restore()

      // ---- screen layer: arrows + nodes + rank badges
      const S2 = (c) => [tr.x + c[0] * tr.k, tr.y + c[1] * tr.k]
      for (const f of V.act) {
        const s = f.strands[Math.floor(f.strands.length / 2)], a = dim(f) * (0.35 + 0.65 * Math.sqrt(f.v / V.amax))
        const [ax, ay] = S2(bez(s.p0, s.c, s.p2, 0.9)), [bx, by] = S2(bez(s.p0, s.c, s.p2, 0.95))
        const ang = Math.atan2(by - ay, bx - ax), L = 5 + 6 * Math.sqrt(f.v / vmax)
        ctx.save(); ctx.translate(bx, by); ctx.rotate(ang); ctx.globalAlpha = Math.min(1, a)
        ctx.beginPath(); ctx.moveTo(L, 0); ctx.lineTo(-L * 0.6, -L * 0.62); ctx.lineTo(-L * 0.2, 0); ctx.lineTo(-L * 0.6, L * 0.62); ctx.closePath()
        ctx.fillStyle = '#fff'; ctx.fill(); ctx.restore()
      }
      const topSet = P.current.topN === 'all' ? null : Number(P.current.topN)
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '700 10px Poppins, sans-serif'
      for (const f of land) {
        const v = V.vals[f.key]; if (v == null) continue
        const [sx, sy] = S2(f.c), r = 3 + 10 * Math.sqrt(Math.abs(v) / V.max) * clamp(Math.pow(rel, 0.25), 1, 1.6)
        const on = f.key === sel, hot = f.key === hovP, con = V.conn.has(f.key) || !sel
        ctx.globalAlpha = con ? 1 : 0.35
        ctx.beginPath(); ctx.arc(sx, sy, r, 0, 6.2832)
        if (v < 0) { ctx.fillStyle = 'rgba(7,27,53,.55)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#fff'; ctx.stroke() }
        else { ctx.fillStyle = on ? '#fff' : 'rgba(255,255,255,.88)'; ctx.fill() }
        if (on || hot) { ctx.beginPath(); ctx.arc(sx, sy, r + 5, 0, 6.2832); ctx.lineWidth = 1.6; ctx.strokeStyle = '#9fd3ff'; ctx.stroke() }
        const rk = V.rank[f.key]
        if (topSet && rk <= topSet && r > 6) { ctx.fillStyle = v < 0 ? '#fff' : '#0B2342'; ctx.fillText(rk, sx, sy + 0.5) }
        ctx.globalAlpha = 1
      }
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)

    // ---- pointer
    let drag = null
    const pos = (ev) => { const r = canvas.getBoundingClientRect(); return [ev.clientX - r.left, ev.clientY - r.top] }
    const world = (x, y) => [(x - tr.x) / tr.k, (y - tr.y) / tr.k]
    const provAt = (x, y) => {
      let best = null, bd = 1e9
      for (const f of land) { const [sx, sy] = [tr.x + f.c[0] * tr.k, tr.y + f.c[1] * tr.k]; const d = Math.hypot(sx - x, sy - y); if (d < 16 && d < bd) { bd = d; best = f.key } }
      if (best) return best
      const [wx, wy] = world(x, y)
      for (const f of land) if (ctx.isPointInPath(f.path, wx, wy)) return f.key
      return null
    }
    const probe = (x, y) => {
      const p = provAt(x, y); if (p) return { p }
      const [wx, wy] = world(x, y); return { f: hitFlow(wx, wy, 6 / tr.k, view.current.act) }
    }
    const onDown = (ev) => { canvas.setPointerCapture(ev.pointerId); const [x, y] = pos(ev); drag = { x, y, tx: tr.x, ty: tr.y, moved: false } }
    const onMove = (ev) => {
      const [x, y] = pos(ev)
      if (drag) {
        const mx = x - drag.x, my = y - drag.y
        if (Math.hypot(mx, my) > 5) drag.moved = true
        if (drag.moved) { tr.x = to.x = drag.tx + mx; tr.y = to.y = drag.ty + my; canvas.style.cursor = 'grabbing'; return }
      }
      const { p, f } = probe(x, y)
      st.current.hov = f || null; st.current.hovProv = p || null
      P.current.onHover?.(p || null)
      canvas.style.cursor = p || f ? 'pointer' : 'grab'
      setTip(p ? { x, y, key: p } : f ? { x, y, flow: f } : null)
    }
    const onUp = (ev) => {
      const d = drag; drag = null; canvas.style.cursor = 'grab'
      if (!d || d.moved) return
      const { p, f } = probe(...pos(ev))
      if (p) { st.current.selFlow = null; P.current.onSelect(p === P.current.sel ? null : p) }
      else if (f) { st.current.selFlow = f; set(fitTo()) } // click a line: pull away
      else { st.current.selFlow = null; P.current.onSelect(null); set(fitTo()) }
    }
    const onLeave = () => { st.current.hov = null; st.current.hovProv = null; P.current.onHover?.(null); setTip(null) }
    const onWheel = (ev) => {
      ev.preventDefault(); const [x, y] = pos(ev)
      const k = clamp(to.k * Math.exp(-ev.deltaY * 0.0015), fitK * 0.9, fitK * 8)
      const wx = (x - to.x) / to.k, wy = (y - to.y) / to.k
      set({ k, x: x - wx * k, y: y - wy * k })
    }
    canvas.addEventListener('pointerdown', onDown); canvas.addEventListener('pointermove', onMove)
    canvas.addEventListener('pointerup', onUp); canvas.addEventListener('pointerleave', onLeave)
    canvas.addEventListener('wheel', onWheel, { passive: false })
    return () => {
      cancelAnimationFrame(raf); window.removeEventListener('resize', resize)
      canvas.removeEventListener('pointerdown', onDown); canvas.removeEventListener('pointermove', onMove)
      canvas.removeEventListener('pointerup', onUp); canvas.removeEventListener('pointerleave', onLeave)
      canvas.removeEventListener('wheel', onWheel)
    }
  }, [])

  const s = tip?.key && statBy[tip.key]
  const G = P.current.gender
  return (
    <>
      <canvas ref={cv} className="absolute inset-0 h-full w-full cursor-grab touch-none" />
      {tip && (
        <div className="pointer-events-none absolute z-30 w-max max-w-[260px] -translate-x-1/2 -translate-y-[112%] rounded-xl bg-white px-3.5 py-2.5 text-navy-900 shadow-glow" style={{ left: clamp(tip.x, 130, 4000), top: Math.max(tip.y, 120) }}>
          {s ? (
            <>
              <div className="text-[12px] font-extrabold uppercase tracking-wide">{s.name}</div>
              {['in', 'out', 'net'].map((k) => (
                <div key={k} className={`mt-0.5 flex justify-between gap-6 text-[12px] ${ind === k ? 'font-bold text-navy-900' : 'text-navy-500'}`}>
                  <span>{k === 'in' ? 'Masuk' : k === 'out' ? 'Keluar' : 'Neto'}{ind === k && ' ●'}</span>
                  <span>{k === 'net' ? nfs(s.netN) : nf(valueOf(s, k, G))}</span>
                </div>
              ))}
              <div className="mt-1.5 text-[10.5px] text-navy-500">Klik untuk menjelajahi wilayah ini.</div>
            </>
          ) : (
            <>
              <div className="text-[12px] font-bold">{tip.flow.label}</div>
              <div className="text-[12px] text-navy-500">{nf(tip.flow.v)} jiwa · klik untuk fokus</div>
            </>
          )}
        </div>
      )}
    </>
  )
}
