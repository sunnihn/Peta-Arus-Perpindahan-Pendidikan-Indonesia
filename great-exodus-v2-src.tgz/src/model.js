// Flow model: every inter-province pair becomes a fanned set of quadratic strands (more migrants = more strands).
import { feats, featBy, od, nameOf, W, H } from './data'
export { feats, featBy, nameOf, W, H }

const ISLAND = {
  sumatera: 'aceh sumaterautara sumaterabarat riau jambi sumateraselatan bengkulu lampung kepulauanbangkabelitung kepulauanriau',
  jawa: 'banten dkijakarta jawabarat jawatengah diyogyakarta jawatimur',
  nusa: 'bali nusatenggarabarat nusatenggaratimur',
  kalimantan: 'kalimantanbarat kalimantantengah kalimantanselatan kalimantantimur kalimantanutara',
  sulawesi: 'sulawesiutara sulawesitengah sulawesiselatan sulawesitenggara gorontalo sulawesibarat',
  maluku: 'maluku malukuutara',
  papua: 'papua papuabarat',
}
const islandOf = {}
Object.entries(ISLAND).forEach(([i, ks]) => ks.split(' ').forEach((k) => (islandOf[k] = i)))
const hash = (s) => [...s].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7)
const rng = (seed) => () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296)

function vehicleFor(a, b, len, r) {
  if (islandOf[a] && islandOf[a] === islandOf[b]) {
    if (len < 40) return r() < 0.5 ? 'student' : r() < 0.5 ? 'bus' : 'car'
    if ((islandOf[a] === 'jawa' || islandOf[a] === 'sumatera') && r() < 0.35) return 'train'
    return r() < 0.5 ? 'bus' : r() < 0.5 ? 'car' : 'student'
  }
  if (len < 230) return r() < 0.7 ? 'ship' : 'bus'
  return r() < 0.8 ? 'plane' : 'ship'
}
const SPEED = { student: 13, bus: 30, car: 38, train: 58, ship: 24, plane: 85 }

const rows = od.filter((r) => r.kind === 'Antar provinsi' && featBy[r.origin] && featBy[r.dest] && r.origin !== r.dest && r.v > 0).sort((a, b) => b.v - a.v)
export const vmax = rows[0].v

export const bez = (p0, c, p2, t) => {
  const u = 1 - t
  return [u * u * p0[0] + 2 * u * t * c[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p2[1]]
}

export const allFlows = rows.map((r, id) => {
  const A = featBy[r.origin].c, B = featBy[r.dest].c
  const dx = B[0] - A[0], dy = B[1] - A[1], len = Math.hypot(dx, dy) || 1
  const nx = -dy / len, ny = dx / len
  const n = 1 + Math.round(Math.sqrt(r.v / vmax) * 14)
  const spread = Math.min(len * 0.1, 1.5 + n * 0.5)
  const rand = rng(hash(r.origin + r.dest))
  const strands = []
  for (let i = 0; i < n; i++) {
    const off = n === 1 ? 0 : (i / (n - 1) - 0.5) * spread + (rand() - 0.5) * 0.6
    const p0 = [A[0] + nx * off * 0.3, A[1] + ny * off * 0.3], p2 = [B[0] + nx * off * 0.3, B[1] + ny * off * 0.3]
    const bend = len * (0.2 + rand() * 0.03) + off
    const c = [(p0[0] + p2[0]) / 2 + nx * bend, (p0[1] + p2[1]) / 2 + ny * bend]
    const pts = Array.from({ length: 24 }, (_, j) => bez(p0, c, p2, j / 23))
    const path = new Path2D(); path.moveTo(...p0); path.quadraticCurveTo(c[0], c[1], p2[0], p2[1])
    strands.push({ p0, c, p2, pts, path, ph: rand(), sp: 0.12 + rand() * 0.12 })
  }
  return { id, from: r.origin, to: r.dest, v: r.v, n, len, strands, rank: id + 1, rand, _t: null, label: `${nameOf(r.origin)} → ${nameOf(r.dest)}` }
})

// Travellers are created lazily so only flows on screen pay for them.
export function travellers(f) {
  if (f._t) return f._t
  const nT = Math.min(8, 1 + Math.round(f.n * 0.4))
  f._t = Array.from({ length: nT }, () => {
    const type = vehicleFor(f.from, f.to, f.len, f.rand)
    const s = f.strands[Math.floor(f.rand() * f.strands.length)]
    return { type, s, t: f.rand(), v: (SPEED[type] * (0.85 + f.rand() * 0.3)) / f.len, seed: f.rand() * 10 }
  })
  return f._t
}
