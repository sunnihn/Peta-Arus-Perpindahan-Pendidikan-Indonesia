// Isometric region diorama: province slab, origin/destination pins and curved arrows toward the centre.
import { useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'

const W = 600, H = 420, L = 9, STEP = 3.4, ANG = (40 * Math.PI) / 180

function sample(el, b, n) {
  const [[x0, y0], [x1, y1]] = b
  const step = Math.max(1.2, Math.min(x1 - x0, y1 - y0) / 24), svg = el.ownerSVGElement, pt = svg.createSVGPoint()
  const inside = (x, y) => { pt.x = x; pt.y = y; return el.isPointInFill(pt) }
  const run = (m) => { const out = []; for (let x = x0; x <= x1; x += step) for (let y = y0; y <= y1; y += step) if (inside(x, y) && (!m || (inside(x + m, y) && inside(x - m, y) && inside(x, y + m) && inside(x, y - m)))) out.push([x, y]); return out }
  let pts = run(step * 1.4); if (pts.length < n) pts = run(0); if (!pts.length) return null
  const cx = pts.reduce((s, p) => s + p[0], 0) / pts.length, cy = pts.reduce((s, p) => s + p[1], 0) / pts.length
  const ch = [[...pts].sort((a, c) => (a[0] - cx) ** 2 + (a[1] - cy) ** 2 - ((c[0] - cx) ** 2 + (c[1] - cy) ** 2))[0]]
  while (ch.length < Math.min(n + 1, pts.length)) { let best = null, bd = -1; pts.forEach((p) => { const d = Math.min(...ch.map((c) => (c[0] - p[0]) ** 2 + (c[1] - p[1]) ** 2)); if (d > bd) { bd = d; best = p } }); ch.push(best) }
  return { ch }
}

export default function Diorama({ feat, items, active, setActive, fmtV, uid, dir }) {
  const ref = useRef(null)
  const [lay, setLay] = useState(null)
  const [[x0, y0], [x1, y1]] = feat.b
  const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2
  const sc = Math.min(W, (H - L * STEP) * 1.7) / (Math.hypot(x1 - x0, y1 - y0) * 0.95)
  const iso = (x, y, lift = 0) => { const px = (x - cx) * sc, py = (y - cy) * sc; return [px * Math.cos(ANG) - py * Math.sin(ANG) + W / 2, (px * Math.sin(ANG) + py * Math.cos(ANG)) * 0.55 + H / 2 + 14 - lift] }
  const T = `translate(${W / 2} ${H / 2 + 14}) scale(1 0.55) rotate(40) scale(${sc}) translate(${-cx} ${-cy})`
  useEffect(() => { if (ref.current) setLay(sample(ref.current, feat.b, items.length)) }, [feat, items.length])
  const max = items[0]?.v || 1
  const hub = lay && iso(lay.ch[0][0], lay.ch[0][1], L * STEP)
  const nodes = useMemo(() => {
    if (!lay) return []
    return items.map((it, i) => { const p = lay.ch[i + 1]; if (!p) return null; const [sx, sy] = iso(p[0], p[1], L * STEP); return { ...it, sx, sy, r: 5 + 11 * Math.sqrt(it.v / max) } }).filter(Boolean)
  }, [lay, items]) // eslint-disable-line react-hooks/exhaustive-deps
  const act = nodes.find((t) => t.label === active)

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-full w-full" role="img" aria-label="Diorama wilayah">
      <defs>
        <linearGradient id={`s${uid}`} x1="0" y1="1" x2="0" y2="0"><stop offset="0" stopColor="#06193a" /><stop offset="1" stopColor="#1f5ca6" /></linearGradient>
        <linearGradient id={`t${uid}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#f4f9ff" /><stop offset="1" stopColor="#8fb8e6" /></linearGradient>
        <marker id={`a${uid}`} viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="#0B2342" /></marker>
      </defs>
      <ellipse cx={W / 2} cy={H / 2 + 78} rx={W * 0.4} ry={50} fill="#000" opacity=".25" />
      {Array.from({ length: L + 1 }, (_, i) => (
        <motion.g key={i} initial={{ y: 0 }} animate={{ y: -i * STEP }} transition={{ duration: 0.8, delay: i * 0.03 }}>
          <g transform={T}><path d={feat.d} ref={i === L ? ref : undefined} fill={i === L ? `url(#t${uid})` : `url(#s${uid})`} stroke={i === L ? '#fff' : '#06193a'} strokeWidth={(i === L ? 1.4 : 0.4) / sc} strokeLinejoin="round" /></g>
        </motion.g>
      ))}
      {hub && nodes.map((t, i) => {
        const mx = (t.sx + hub[0]) / 2, my = (t.sy + hub[1]) / 2 - 22
        const tp = [t.sx, t.sy], [a, b] = dir === 'out' ? [hub, tp] : [tp, hub]
        const on = active === t.label
        return <motion.path key={`l${t.label}`} d={`M${a[0]} ${a[1]} Q${mx} ${my} ${b[0]} ${b[1]}`} fill="none" stroke={on ? '#071B35' : '#2a6cb8'} strokeWidth={0.8 + 3 * (t.v / max)} strokeOpacity={on ? 1 : 0.55} markerEnd={`url(#a${uid})`} initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.6 + i * 0.05, duration: 0.8 }} />
      })}
      {hub && <g><circle cx={hub[0]} cy={hub[1]} r="9" fill="#0B2342" stroke="#fff" strokeWidth="2" /><circle cx={hub[0]} cy={hub[1]} r="15" fill="none" stroke="#0B2342" strokeOpacity=".4"><animate attributeName="r" values="11;22;11" dur="2.6s" repeatCount="indefinite" /><animate attributeName="stroke-opacity" values=".5;0;.5" dur="2.6s" repeatCount="indefinite" /></circle></g>}
      {nodes.map((t, i) => {
        const on = active === t.label
        return (
          <motion.g key={t.label} initial={{ opacity: 0, y: -14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 + i * 0.05, type: 'spring', stiffness: 220, damping: 18 }} style={{ cursor: 'pointer' }} onMouseEnter={() => setActive(t.label)} onMouseLeave={() => setActive(null)}>
            <ellipse cx={t.sx} cy={t.sy + 2} rx={t.r * 0.7} ry={t.r * 0.28} fill="#000" opacity=".3" />
            <path d={`M${t.sx} ${t.sy} C${t.sx - t.r * 1.1} ${t.sy - t.r * 1.2} ${t.sx - t.r} ${t.sy - t.r * 2.4} ${t.sx} ${t.sy - t.r * 2.4} C${t.sx + t.r} ${t.sy - t.r * 2.4} ${t.sx + t.r * 1.1} ${t.sy - t.r * 1.2} ${t.sx} ${t.sy}Z`} fill={on ? '#071B35' : '#174A7E'} stroke="#fff" strokeWidth="1.5" />
            <circle cx={t.sx} cy={t.sy - t.r * 1.55} r={t.r * 0.42} fill="#fff" />
            {i < 3 && !on && <text x={t.sx} y={t.sy - t.r * 2.6 - 3} textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#fff" stroke="#06193a" strokeWidth="2.6" paintOrder="stroke">{t.label}</text>}
          </motion.g>
        )
      })}
      {act && (
        <g pointerEvents="none" transform={`translate(${Math.min(Math.max(act.sx, 100), W - 100)} ${Math.max(act.sy - act.r * 2.4 - 14, 56)})`}>
          <rect x="-95" y="-46" width="190" height="44" rx="10" fill="#fff" />
          <text y="-29" textAnchor="middle" fontSize="10" fill="#3974A9">{act.label}</text>
          <text y="-11" textAnchor="middle" fontSize="13" fontWeight="700" fill="#071B35">{fmtV(act)}</text>
        </g>
      )}
    </svg>
  )
}
