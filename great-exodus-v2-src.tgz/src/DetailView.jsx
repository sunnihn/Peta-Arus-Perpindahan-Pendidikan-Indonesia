import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft } from 'lucide-react'
import Diorama from './Diorama'
import { Card, BarRow, Sub, Seg } from './ui'
import { statBy, rankMap, odLists, insight, nameOf, nf, nfs, pc, JATENG, nProv } from './derived'
import { featBy } from './data'

export default function DetailView({ id, back }) {
  const s = statBy[id], L = odLists(id), feat = featBy[id]
  const [tab, setTab] = useState('asal')
  const [active, setActive] = useState(null)
  const [cat, setCat] = useState(null)
  const isJT = id === 'jawatengah'
  const rIn = rankMap('in')[id], rNet = rankMap('net')[id]

  const items = useMemo(() => {
    const rows = tab === 'asal'
      ? [...L.inn.map((r) => ({ label: nameOf(r.origin), v: r.v })), ...(L.abroad ? [{ label: 'Luar Negeri', v: L.abroad }] : [])]
      : L.out.map((r) => ({ label: nameOf(r.dest), v: r.v }))
    const top = rows.sort((a, b) => b.v - a.v).slice(0, 8), tot = rows.reduce((x, r) => x + r.v, 0)
    return top.map((r) => ({ ...r, share: r.v / (tot || 1) }))
  }, [id, tab]) // eslint-disable-line react-hooks/exhaustive-deps

  const genT = s.mL + s.mP
  const pick = (g, label, v, total) => setCat(cat?.label === label ? null : { g, label, v, total })
  const ageT = JATENG.age.reduce((x, r) => x + r.v, 0), eduT = JATENG.edu.reduce((x, r) => x + r.v, 0)
  const maxOf = (a) => Math.max(...a.map((r) => r.v))
  const topAge = [...JATENG.age].sort((a, b) => b.v - a.v)[0], topEdu = [...JATENG.edu].sort((a, b) => b.v - a.v)[0]
  const text = insight(id) + (isJT ? ` Di kab/kota Jawa Tengah, kelompok umur ${topAge.label} terbesar (${pc(topAge.v / ageT, 0)}) dan pendidikan ${topEdu.label} paling banyak (${pc(topEdu.v / eduT, 0)}).` : '')
  const stat = (l, v, sub) => (<div className="rounded-xl bg-white/10 px-3 py-2"><div className="text-[10px] text-navy-300">{l}</div><div className="text-[15px] font-bold tabular-nums text-white">{v}</div><div className="text-[10px] text-navy-300">{sub}</div></div>)
  const Row = ({ g, r, total, mx }) => <BarRow key={r.label} label={r.label} text={`${nf(r.v)} · ${pc(r.v / total, 0)}`} frac={r.v / mx} active={cat?.label === r.label} onClick={() => pick(g, r.label, r.v, total)} />
  const na = <p className="px-2 pb-1 text-[11px] leading-snug text-navy-300">Belum tersedia di level provinsi. BPS hanya memuat rincian ini untuk kab/kota Jawa Tengah.</p>

  return (
    <motion.section initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.45 }} className="absolute inset-0 z-40 overflow-y-auto bg-[radial-gradient(120%_90%_at_30%_10%,#0F4C9A_0%,#08295C_48%,#041433_100%)]">
      <div className="mx-auto grid max-w-[1500px] gap-4 p-4 md:h-full md:grid-cols-[1fr_370px] md:p-7">
        <div className="flex min-h-0 flex-col">
          <button onClick={back} className="flex w-fit items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-[13px] font-semibold text-white ring-1 ring-white/15 hover:bg-white/20"><ArrowLeft size={15} /> Peta</button>
          <div className="mt-4 text-[11px] font-semibold uppercase tracking-[0.3em] text-navy-300">Kamu sedang menjelajah</div>
          <h2 className="text-[34px] font-extrabold uppercase leading-none tracking-tight text-white md:text-[52px]">{s.name}</h2>
          <div className="mt-4 grid max-w-[640px] grid-cols-2 gap-2 sm:grid-cols-4">
            {stat('Peringkat masuk', `#${rIn}`, `dari ${nProv} provinsi`)}
            {stat('Masuk', nf(s.inN), `${pc(s.in, 2)} pddk 5+`)}
            {stat('Keluar', nf(s.outN), `${pc(s.out, 2)} pddk 5+`)}
            {stat('Neto', nfs(s.netN), `#${rNet} · ${pc(Math.abs(s.net), 2)}`)}
          </div>
          <div className="relative mt-1 flex min-h-[300px] flex-1 flex-col">
            <div className="flex justify-center"><Seg uid="dt" label="" value={tab} onChange={setTab} options={[{ id: 'asal', label: 'Datang dari' }, { id: 'tujuan', label: 'Pergi ke' }]} /></div>
            <div className="min-h-0 flex-1 overflow-hidden">
              {feat
                ? <Diorama key={id + tab} uid={id + tab} feat={feat} items={items} active={active} setActive={setActive} dir={tab === 'tujuan' ? 'out' : 'in'} fmtV={(t) => `${nf(t.v)} · ${pc(t.share, 0)}`} />
                : <div className="grid h-full place-items-center text-center text-[13px] text-navy-300">Poligon wilayah ini tidak ada di peta dasar.<br />Angka tetap tersedia di panel.</div>}
            </div>
            {cat && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="absolute bottom-2 left-1/2 w-[min(420px,92%)] -translate-x-1/2 rounded-2xl bg-white px-4 py-3 text-navy-900 shadow-glow">
                <div className="flex items-baseline justify-between"><b className="text-[13px]">{cat.label}</b><span className="text-[12px] tabular-nums">{nf(cat.v)} jiwa</span></div>
                <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-navy-100"><motion.div key={cat.label} initial={{ width: 0 }} animate={{ width: `${(cat.v / cat.total) * 100}%` }} className="h-full rounded-full bg-gradient-to-r from-navy-500 to-navy-900" /></div>
                <div className="mt-1 text-[11px] text-navy-500">{pc(cat.v / cat.total, 1)} dari {nf(cat.total)} migran ({cat.g === 'gender' ? 'masuk' : 'kab/kota Jateng'})</div>
              </motion.div>
            )}
          </div>
          <Card className="mt-2 shrink-0 p-4">
            <div className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-navy-300">Regional insight</div>
            <p className="mt-1.5 max-w-[860px] text-[13.5px] leading-relaxed text-white">{text}</p>
          </Card>
        </div>

        <Card className="h-fit p-3 md:sticky md:top-7 md:max-h-[calc(100vh-56px)] md:overflow-y-auto">
          <Sub>Migration overview</Sub>
          <BarRow label="Masuk" text={`${nf(s.inN)} · ${pc(s.in, 2)}`} frac={s.inN / Math.max(s.inN, s.outN)} />
          <BarRow label="Keluar" text={`${nf(s.outN)} · ${pc(s.out, 2)}`} frac={s.outN / Math.max(s.inN, s.outN)} />
          <BarRow label="Neto" text={`${nfs(s.netN)} · ${pc(Math.abs(s.net), 2)}`} frac={Math.abs(s.netN) / Math.max(s.inN, s.outN)} tone={s.netN < 0 ? 'neg' : 'blue'} />
          <Sub>Demographic profile</Sub>
          <Row g="gender" r={{ label: 'Laki-laki', v: s.mL }} total={genT} mx={Math.max(s.mL, s.mP)} />
          <Row g="gender" r={{ label: 'Perempuan', v: s.mP }} total={genT} mx={Math.max(s.mL, s.mP)} />
          <Sub right={isJT ? 'kab/kota Jateng' : ''}>Kelompok umur</Sub>
          {isJT ? JATENG.age.map((r) => <Row key={r.label} g="age" r={r} total={ageT} mx={maxOf(JATENG.age)} />) : na}
          <Sub right={isJT ? 'kab/kota Jateng' : ''}>Education profile</Sub>
          {isJT ? JATENG.edu.map((r) => <Row key={r.label} g="edu" r={r} total={eduT} mx={maxOf(JATENG.edu)} />) : na}
          <p className="px-2 pt-2 text-[10.5px] leading-snug text-navy-300">Sumber: BPS Long Form SP2020, migran risen (5 tahun lalu ≠ kini), penduduk 5+. Keluar dihitung dari angka BPS.{isJT && ' Umur &amp; pendidikan memuat pindahan antar kab/kota.'}</p>
        </Card>
      </div>
    </motion.section>
  )
}
