import { motion } from 'framer-motion'
import { ChevronDown, SlidersHorizontal, X } from 'lucide-react'

export const Card = ({ className = '', children, ...p }) => (
  <div className={`rounded-2xl border border-white/10 bg-navy-950/60 shadow-glow backdrop-blur-md ${className}`} {...p}>{children}</div>
)

export function Seg({ label, value, onChange, options, uid, disabled }) {
  return (
    <div className={`flex items-center gap-2 ${disabled ? 'opacity-45' : ''}`} title={disabled ? 'Pilih wilayah di peta dulu' : undefined}>
      <span className="hidden text-[10.5px] font-semibold uppercase tracking-[0.14em] text-navy-300 min-[1700px]:block">{label}</span>
      <div className="relative flex rounded-full bg-white/10 p-0.5">
        {options.map((o) => (
          <button key={o.id} disabled={disabled} onClick={() => onChange(o.id)} className={`relative whitespace-nowrap rounded-full px-3 py-1.5 text-[12px] font-semibold transition-colors ${value === o.id ? 'text-navy-900' : 'text-navy-100 hover:text-white'}`}>
            {value === o.id && <motion.span layoutId={`seg-${uid}`} className="absolute inset-0 rounded-full bg-white" transition={{ type: 'spring', stiffness: 420, damping: 34 }} />}
            <span className="relative">{o.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

export const Chip = ({ children, onClear }) => (
  <span className="inline-flex items-center gap-1 whitespace-nowrap rounded-full bg-white/12 px-2.5 py-1 text-[11px] font-medium text-navy-100 ring-1 ring-white/15">
    {children}{onClear && <button onClick={onClear} aria-label="hapus"><X size={11} /></button>}
  </span>
)

export const FilterToggle = ({ open, onClick, count }) => (
  <button onClick={onClick} className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-2 text-[12px] font-semibold text-white ring-1 ring-white/15 hover:bg-white/20">
    <SlidersHorizontal size={13} /> Filter{count > 0 && <span className="rounded-full bg-white px-1.5 text-[10px] font-bold text-navy-900">{count}</span>}
    <ChevronDown size={13} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
  </button>
)

// Horizontal bar row used in all lists
export function BarRow({ label, value, text, frac, active, onClick, onEnter, onLeave, rank, tone = 'blue' }) {
  return (
    <button onClick={onClick} onMouseEnter={onEnter} onMouseLeave={onLeave} className={`group block w-full rounded-lg px-2 py-1.5 text-left transition-colors ${active ? 'bg-white/15' : 'hover:bg-white/8'}`}>
      <div className="flex items-baseline justify-between gap-3 text-[12px]">
        <span className="truncate font-medium text-white">{rank != null && <b className="mr-1.5 text-navy-300">{rank}</b>}{label}</span>
        <span className="shrink-0 tabular-nums text-navy-100">{text ?? value}</span>
      </div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/10">
        <motion.div initial={{ width: 0 }} animate={{ width: `${Math.max(2, frac * 100)}%` }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} className={`h-full rounded-full ${tone === 'neg' ? 'bg-navy-100' : 'bg-gradient-to-r from-[#3d8be0] to-white'}`} />
      </div>
    </button>
  )
}

export const Sub = ({ children, right }) => (
  <div className="mb-1 mt-3 flex items-center justify-between px-2 text-[10.5px] font-semibold uppercase tracking-[0.16em] text-navy-300">
    <span>{children}</span>{right && <span className="normal-case tracking-normal">{right}</span>}
  </div>
)
