// Vector sprites drawn in a 24x24 box centred on (0,0), facing +x. Blue/white only.
const INK = '#071B35', WHITE = '#FFFFFF', SKY = '#BFD9F5', BLUE = '#2F6FBF', DEEP = '#174A7E'

const rr = (c, x, y, w, h, r) => { c.beginPath(); c.roundRect(x, y, w, h, r) }
const fs = (c, fill, lw = 0.9) => { c.fillStyle = fill; c.fill(); c.lineWidth = lw; c.strokeStyle = INK; c.stroke() }
const wheel = (c, x, y, r) => {
  c.beginPath(); c.arc(x, y, r, 0, 6.2832); fs(c, INK, 0.5)
  c.beginPath(); c.arc(x, y, r * 0.42, 0, 6.2832); c.fillStyle = SKY; c.fill()
}

function student(c, t) {
  const sw = Math.sin(t * 9) // gait
  c.lineCap = 'round'
  // legs
  c.strokeStyle = INK; c.lineWidth = 2.1
  c.beginPath(); c.moveTo(0, 2); c.lineTo(sw * 3.2, 10); c.moveTo(0, 2); c.lineTo(-sw * 3.2, 10); c.stroke()
  c.strokeStyle = DEEP; c.lineWidth = 1.2
  c.beginPath(); c.moveTo(0, 2); c.lineTo(sw * 3.2, 10); c.moveTo(0, 2); c.lineTo(-sw * 3.2, 10); c.stroke()
  // backpack
  rr(c, -6.4, -5.6, 4.4, 8, 1.4); fs(c, BLUE)
  // torso
  rr(c, -3.2, -6, 6.4, 9, 2.2); fs(c, WHITE)
  // arm
  c.strokeStyle = INK; c.lineWidth = 1.8
  c.beginPath(); c.moveTo(0, -4); c.lineTo(-sw * 3, 1.2); c.stroke()
  c.strokeStyle = WHITE; c.lineWidth = 0.9
  c.beginPath(); c.moveTo(0, -4); c.lineTo(-sw * 3, 1.2); c.stroke()
  // head
  c.beginPath(); c.arc(0.4, -9.2, 3, 0, 6.2832); fs(c, SKY)
  // graduation cap
  c.beginPath(); c.moveTo(-3.6, -11.2); c.lineTo(0.4, -13.2); c.lineTo(4.4, -11.2); c.lineTo(0.4, -9.6); c.closePath(); fs(c, INK, 0.5)
  c.strokeStyle = WHITE; c.lineWidth = 0.7
  c.beginPath(); c.moveTo(4.2, -11.2); c.lineTo(4.6, -8); c.stroke()
}

function bus(c) {
  rr(c, -11, -6, 22, 11, 2.4); fs(c, WHITE)
  c.fillStyle = BLUE; c.fillRect(-10.5, 1, 21, 1.8)
  for (let i = 0; i < 4; i++) { rr(c, -9.4 + i * 4.5, -4.6, 3.6, 3.6, 0.7); c.fillStyle = SKY; c.fill() }
  rr(c, 8, -4.6, 2.6, 5.4, 0.8); c.fillStyle = DEEP; c.fill()
  wheel(c, -6.5, 5.4, 2.3); wheel(c, 6.5, 5.4, 2.3)
}

function car(c) {
  c.beginPath(); c.moveTo(-11, 3); c.lineTo(-11, -0.5); c.lineTo(-7, -1.4); c.lineTo(-4.4, -5.8); c.lineTo(3.6, -5.8); c.lineTo(6.6, -1.4); c.lineTo(11, -0.2); c.lineTo(11, 3); c.closePath(); fs(c, WHITE)
  c.beginPath(); c.moveTo(-3.6, -1.6); c.lineTo(-2.4, -4.8); c.lineTo(0.3, -4.8); c.lineTo(0.3, -1.6); c.closePath(); c.fillStyle = SKY; c.fill()
  c.beginPath(); c.moveTo(1.4, -1.6); c.lineTo(1.4, -4.8); c.lineTo(3, -4.8); c.lineTo(5, -1.6); c.closePath(); c.fillStyle = SKY; c.fill()
  c.fillStyle = BLUE; c.fillRect(-10.5, 0.6, 21, 1.1)
  wheel(c, -6.4, 3.6, 2.5); wheel(c, 6.4, 3.6, 2.5)
}

function train(c) {
  for (let i = 0; i < 2; i++) {
    const x = -12 + i * 12.5
    rr(c, x, -5, i ? 11.5 : 11, 9, i ? 3.4 : 1.4); fs(c, WHITE)
    for (let j = 0; j < 3; j++) { rr(c, x + 1.4 + j * 3.2, -3.4, 2.4, 2.6, 0.5); c.fillStyle = SKY; c.fill() }
    c.fillStyle = BLUE; c.fillRect(x + 0.5, 1.3, 10, 1.3)
    wheel(c, x + 2.6, 4.8, 1.5); wheel(c, x + 8.4, 4.8, 1.5)
  }
  c.fillStyle = INK; c.fillRect(-1, 0.2, 1.6, 1)
}

function plane(c) { // top view, nose +x
  c.beginPath(); c.moveTo(-3, 0); c.lineTo(-8, -10); c.lineTo(-4.6, -10); c.lineTo(3.6, -1.6); c.lineTo(3.6, 1.6); c.lineTo(-4.6, 10); c.lineTo(-8, 10); c.closePath(); fs(c, SKY)
  c.beginPath(); c.moveTo(-11.5, -1.2); c.lineTo(-13.5, -5); c.lineTo(-11, -5); c.lineTo(-8.5, -1.2); c.lineTo(-8.5, 1.2); c.lineTo(-11, 5); c.lineTo(-13.5, 5); c.lineTo(-11.5, 1.2); c.closePath(); fs(c, SKY)
  c.beginPath(); c.moveTo(-12, -1.5); c.quadraticCurveTo(-12.5, 0, -12, 1.5); c.lineTo(8, 1.7); c.quadraticCurveTo(12.5, 0, 8, -1.7); c.closePath(); fs(c, WHITE)
  c.fillStyle = BLUE; c.beginPath(); c.ellipse(8.2, 0, 2, 0.9, 0, 0, 6.2832); c.fill()
}

function ship(c, t) {
  c.save(); c.translate(0, Math.sin(t * 2.4) * 0.8); c.rotate(Math.sin(t * 1.7) * 0.04)
  rr(c, -2, -9, 8, 5, 1); fs(c, WHITE)        // bridge
  rr(c, -9, -5.4, 14, 4, 0.8); fs(c, SKY)     // deck house
  c.fillStyle = BLUE; c.fillRect(-7.4, -9, 2.8, 4)  // funnel
  for (let i = 0; i < 4; i++) { c.fillStyle = DEEP; c.fillRect(-8 + i * 3.2, -4.6, 1.6, 1.4) }
  c.beginPath(); c.moveTo(-13, -1.6); c.lineTo(11, -1.6); c.lineTo(14, -2.4); c.lineTo(8.4, 4.6); c.lineTo(-10.6, 4.6); c.closePath(); fs(c, WHITE)
  c.fillStyle = BLUE; c.fillRect(-11.6, 1.2, 21.4, 1.4)
  c.restore()
  c.strokeStyle = 'rgba(255,255,255,.75)'; c.lineWidth = 0.8; c.lineCap = 'round'
  c.beginPath(); c.moveTo(-14, 6.4); c.quadraticCurveTo(-10, 4.6, -6, 6.4); c.quadraticCurveTo(-2, 8.2, 2, 6.4); c.quadraticCurveTo(6, 4.6, 10, 6.4); c.stroke()
}

const MAP = { student, bus, car, train, plane, ship }

// Draw one traveller. dx,dy = heading in screen space. Ground vehicles mirror, planes rotate.
export function drawSprite(c, type, t, dx, dy) {
  if (type === 'plane') {
    c.save(); c.translate(1.5, 2.5); c.globalAlpha *= 0.25; c.fillStyle = INK; c.rotate(Math.atan2(dy, dx)); c.scale(0.9, 0.9)
    c.beginPath(); c.ellipse(0, 0, 12, 3, 0, 0, 6.2832); c.fill(); c.restore()
    c.save(); c.rotate(Math.atan2(dy, dx)); plane(c); c.restore()
    return
  }
  const left = dx < 0
  const ang = Math.max(-0.5, Math.min(0.5, Math.atan2(dy, Math.abs(dx))))
  c.save()
  if (left) c.scale(-1, 1)
  if (type !== 'student') c.rotate(ang)
  MAP[type](c, t)
  c.restore()
}
