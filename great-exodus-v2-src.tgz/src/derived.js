// Province stats (counts derived from BPS rates), ranks, and short evidence-based insight text.
import { prov, od, provBy, featBy, nameOf } from './data'
import jateng from './jateng.json'

export { nameOf, provBy, featBy }
export const JATENG = jateng

export const stats = prov.map((p) => {
  const inN = p.mig, outN = (p.out * (p.pop - inN)) / (1 - p.out)
  return { ...p, inN, outN, netN: inN - outN }
})
export const statBy = Object.fromEntries(stats.map((s) => [s.key, s]))

// value of an indicator; gender applies to incoming only (BPS gives L/P for in-migrants)
export const valueOf = (s, ind, gender) => {
  if (ind === 'in') return gender === 'L' ? s.mL : gender === 'P' ? s.mP : s.inN
  return ind === 'out' ? s.outN : s.netN
}
export const IND = { in: 'Masuk', out: 'Keluar', net: 'Neto' }
export const GEN = { all: 'Semua', L: 'Laki-laki', P: 'Perempuan' }

export const ranking = (ind, gender) =>
  [...stats].sort((a, b) => (ind === 'net' ? b.netN - a.netN : valueOf(b, ind, gender) - valueOf(a, ind, gender)))
export const rankMap = (ind, gender) => Object.fromEntries(ranking(ind, gender).map((s, i) => [s.key, i + 1]))

export const totalMig = stats.reduce((s, p) => s + p.inN, 0)
export const nProv = stats.length

export const nf = (v) => Math.round(v).toLocaleString('id-ID')
export const nfs = (v) => (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(Math.round(v)).toLocaleString('id-ID')
export const pc = (v, d = 1) => (v * 100).toLocaleString('id-ID', { minimumFractionDigits: d, maximumFractionDigits: d }) + '%'

// OD lists for one province
export function odLists(key) {
  const inn = od.filter((r) => r.dest === key && r.kind === 'Antar provinsi').sort((a, b) => b.v - a.v)
  const out = od.filter((r) => r.origin === key && r.kind === 'Antar provinsi').sort((a, b) => b.v - a.v)
  const abroad = od.find((r) => r.dest === key && r.kind === 'Dari luar negeri')?.v ?? 0
  const within = od.find((r) => r.dest === key && r.kind.startsWith('Dalam'))?.v ?? 0
  return { inn, out, abroad, within, inTot: inn.reduce((s, r) => s + r.v, 0), outTot: out.reduce((s, r) => s + r.v, 0) }
}

// 2–3 sentence interpretation, Indonesian, every number comes from the workbook.
export function insight(key) {
  const s = statBy[key], L = odLists(key)
  const rIn = rankMap('in')[key], rOut = rankMap('out')[key], rNet = rankMap('net')[key]
  const parts = []
  const dir = s.netN > 0 ? 'lebih banyak yang datang daripada pergi' : 'lebih banyak yang pergi daripada datang'
  parts.push(`${s.name} menerima ${nf(s.inN)} migran dan melepas sekitar ${nf(s.outN)} orang, jadi ${dir} (neto ${nfs(s.netN)}, peringkat ${rNet} dari ${nProv}).`)
  if (L.inn[0]) parts.push(`Pendatang terbanyak berasal dari ${nameOf(L.inn[0].origin)} (${pc(L.inn[0].v / (L.inTot || 1), 0)} dari arus antarprovinsi masuk)${L.out[0] ? `, sedangkan tujuan favorit warganya adalah ${nameOf(L.out[0].dest)}` : ''}.`)
  const fem = s.mP / (s.mL + s.mP)
  parts.push(`Migran masuknya ${fem >= 0.5 ? 'sedikit lebih banyak perempuan' : 'sedikit lebih banyak laki-laki'} (${pc(Math.max(fem, 1 - fem), 0)}).`)
  return parts.join(' ')
}
