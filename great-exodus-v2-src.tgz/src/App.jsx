import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import FlowCanvas from './FlowCanvas'
import SidePanel from './SidePanel'
import DetailView from './DetailView'
import Legend from './Legend'
import { Seg, Chip, FilterToggle, Card } from './ui'
import { GEN, IND, totalMig, nProv, nf, nameOf } from './derived'

const L1 = 'EDUCATION MIGRATION,'.split(' '), L2 = 'THE GREAT EXODUS?'.split(' ')
const Word = ({ children, i }) => (
  <motion.span initial={{ opacity: 0, y: 24, filter: 'blur(8px)' }} animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }} transition={{ delay: 0.15 + i * 0.12, duration: 0.9, ease: [0.22, 1, 0.36, 1] }} className="mr-[0.28em] inline-block">{children}</motion.span>
)
const IND_O = [{ id: 'in', label: 'Masuk' }, { id: 'out', label: 'Keluar' }, { id: 'net', label: 'Neto' }]
const FLOW_O = [{ id: 'origin', label: 'Asal' }, { id: 'dest', label: 'Tujuan' }, { id: 'both', label: 'Keduanya' }]
const TOP_O = [{ id: '5', label: 'Top 5' }, { id: '10', label: 'Top 10' }, { id: 'all', label: 'Semua' }]
const FLOW_L = { origin: 'Asal', dest: 'Tujuan', both: 'Keduanya' }

export default function App() {
  const [ind, setInd] = useState('in'), [mode, setMode] = useState('both'), [topN, setTopN] = useState('10'), [gender, setGender] = useState('all')
  const [sel, setSel] = useState(null), [hover, setHover] = useState(null), [page, setPage] = useState(null), [fOpen, setFOpen] = useState(false)
  const nFilters = gender !== 'all' ? 1 : 0

  return (
    <main className="relative h-full w-full overflow-hidden">
      <FlowCanvas ind={ind} gender={gender} mode={mode} topN={topN} sel={sel} hoverKey={hover} onSelect={setSel} onHover={setHover} />

      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex flex-col gap-3 p-4 md:flex-row md:justify-between md:p-6">
        <div className="shrink-0 select-none md:max-w-[560px]">
          <h1 className="leading-[1.02] text-white">
            <span className="block text-[12px] font-medium tracking-[0.32em] text-navy-300 sm:text-[14px]">{L1.map((w, i) => <Word key={w} i={i}>{w}</Word>)}</span>
            <span className="mt-1 block text-[26px] font-extrabold tracking-tight sm:text-[36px] md:text-[44px]">{L2.map((w, i) => <Word key={w} i={i + 2}>{w}</Word>)}</span>
          </h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }} className="mt-2 max-w-[460px] text-[11.5px] leading-snug text-navy-100">
            BPS Long Form SP2020 · migran risen (tinggal di provinsi lain 5 tahun lalu) · penduduk 5+ · {nProv} provinsi · {nf(totalMig)} migran.
          </motion.p>
        </div>

        <div className="pointer-events-auto flex flex-col items-start gap-2 md:items-end">
          <Card className="flex flex-wrap items-center gap-x-3 gap-y-2 px-2.5 py-1.5">
            <Seg uid="i" label="Indikator" value={ind} onChange={setInd} options={IND_O} />
            <Seg uid="f" label="Arus" value={mode} onChange={setMode} options={FLOW_O} disabled={!sel} />
            <Seg uid="t" label="Peringkat" value={topN} onChange={setTopN} options={TOP_O} />
            <FilterToggle open={fOpen} onClick={() => setFOpen(!fOpen)} count={nFilters} />
          </Card>
          <div className="flex flex-wrap items-center gap-1.5 md:justify-end">
            <Chip>Indikator: {IND[ind]}{ind === 'in' && gender !== 'all' ? ` · ${GEN[gender]}` : ''}</Chip>
            <Chip>Arus: {FLOW_L[mode]}</Chip>
            <Chip>{topN === 'all' ? 'Semua' : `Top ${topN}`}</Chip>
            {sel && <Chip onClear={() => setSel(null)}>{nameOf(sel)}</Chip>}
            {gender !== 'all' && <Chip onClear={() => setGender('all')}>{GEN[gender]}{ind !== 'in' ? ' (hanya Masuk)' : ''}</Chip>}
          </div>
          <AnimatePresence>
            {fOpen && (
              <motion.div initial={{ opacity: 0, y: -8, height: 0 }} animate={{ opacity: 1, y: 0, height: 'auto' }} exit={{ opacity: 0, y: -8, height: 0 }} className="w-full overflow-hidden md:w-[360px]">
                <Card className="space-y-3 p-3.5">
                  <div>
                    <div className="mb-1.5 text-[10.5px] font-semibold uppercase tracking-[0.16em] text-navy-300">Jenis kelamin · migran masuk</div>
                    <Seg uid="g" label="" value={gender} onChange={setGender} options={[{ id: 'all', label: 'Semua' }, { id: 'L', label: 'Laki-laki' }, { id: 'P', label: 'Perempuan' }]} />
                  </div>
                  {[['Kelompok umur', 'Hanya ada untuk kab/kota Jawa Tengah.'], ['Tingkat pendidikan', 'Hanya ada untuk kab/kota Jawa Tengah.']].map(([t, n]) => (
                    <div key={t} className="opacity-60">
                      <div className="text-[10.5px] font-semibold uppercase tracking-[0.16em] text-navy-300">{t}</div>
                      <div className="text-[11px] text-navy-100">{n} Buka halaman Jawa Tengah untuk melihatnya.</div>
                    </div>
                  ))}
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-4 left-4 z-20 hidden md:block"><Legend /></div>
      <SidePanel ind={ind} gender={gender} mode={mode} topN={topN} sel={sel} setSel={setSel} setHover={setHover} open={setPage} />
      <AnimatePresence>{page && <DetailView key={page} id={page} back={() => setPage(null)} />}</AnimatePresence>
    </main>
  )
}
