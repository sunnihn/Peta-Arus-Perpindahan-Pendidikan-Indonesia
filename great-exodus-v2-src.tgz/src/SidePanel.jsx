import { motion } from 'framer-motion'
import { ArrowRight, X } from 'lucide-react'
import { Card, BarRow, Sub } from './ui'
import { ranking, valueOf, statBy, rankMap, odLists, nameOf, nf, nfs, pc, IND, nProv } from './derived'

const fracOf = (v, max) => Math.abs(v) / (max || 1)

export default function SidePanel({ ind, gender, mode, topN, sel, setSel, setHover, open }) {
  const cls = 'absolute z-20 left-3 right-3 bottom-3 max-h-[42%] md:left-auto md:right-4 md:top-[150px] md:bottom-4 md:max-h-none md:w-[330px]'
  if (!sel) {
    const all = ranking(ind, gender), list = topN === 'all' ? all : all.slice(0, Number(topN))
    const max = Math.abs(valueOf(all[ind === 'net' ? 0 : 0], ind, gender)) || 1
    const mx = Math.max(...all.map((s) => Math.abs(valueOf(s, ind, gender))))
    return (
      <Card className={`${cls} flex flex-col overflow-hidden p-3`}>
        <div className="flex items-baseline justify-between px-2 pb-1">
          <h2 className="text-[15px] font-bold text-white">Peringkat · {IND[ind]}</h2>
          <span className="text-[11px] text-navy-300">{topN === 'all' ? `${nProv} provinsi` : `Top ${topN}`} · jiwa</span>
        </div>
        <div className="-mr-1 flex-1 space-y-0.5 overflow-y-auto pr-1">
          {list.map((s, i) => {
            const v = valueOf(s, ind, gender)
            return <BarRow key={s.key} rank={i + 1} label={s.name} text={ind === 'net' ? nfs(v) : nf(v)} frac={fracOf(v, mx)} tone={v < 0 ? 'neg' : 'blue'} onClick={() => setSel(s.key)} onEnter={() => setHover(s.key)} onLeave={() => setHover(null)} />
          })}
        </div>
        <p className="px-2 pt-2 text-[10.5px] leading-snug text-navy-300">{ind === 'net' ? 'Neto = masuk − keluar. Kosong/terang = lebih banyak yang pergi.' : 'Klik provinsi untuk melihat arus masuk dan keluarnya.'}</p>
      </Card>
    )
  }
  const s = statBy[sel], L = odLists(sel), rk = rankMap(ind, gender)[sel]
  const top = (rows, key) => rows.slice(0, 5).map((r) => ({ label: nameOf(r[key]), v: r.v, key: r[key] }))
  const ins = top(L.inn, 'origin'), outs = top(L.out, 'dest')
  const mI = ins[0]?.v || 1, mO = outs[0]?.v || 1
  const tiles = [['in', 'Masuk', nf(valueOf(s, 'in', gender))], ['out', 'Keluar', nf(s.outN)], ['net', 'Neto', nfs(s.netN)]]
  return (
    <motion.div key={sel} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }} className={cls}>
      <Card className="flex h-full flex-col overflow-hidden p-3.5">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[10.5px] font-semibold uppercase tracking-[0.16em] text-navy-300">Wilayah terpilih</div>
            <h2 className="text-[22px] font-extrabold leading-tight text-white">{s.name}</h2>
            <div className="mt-1 text-[11.5px] text-navy-100">#{rk} dari {nProv} · {IND[ind].toLowerCase()}</div>
          </div>
          <button onClick={() => setSel(null)} className="rounded-full bg-white/10 p-1.5 text-white hover:bg-white/20" aria-label="tutup"><X size={14} /></button>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-1.5">
          {tiles.map(([k, l, v]) => (
            <div key={k} className={`rounded-xl px-2.5 py-2 ${ind === k ? 'bg-white text-navy-900' : 'bg-white/10 text-white'}`}>
              <div className={`text-[10px] ${ind === k ? 'text-navy-500' : 'text-navy-300'}`}>{l}</div>
              <div className="text-[13px] font-bold tabular-nums">{v}</div>
              <div className={`text-[10px] tabular-nums ${ind === k ? 'text-navy-500' : 'text-navy-300'}`}>{pc(k === 'in' ? s.in : k === 'out' ? s.out : Math.abs(s.net), 2)}</div>
            </div>
          ))}
        </div>
        <div className="-mr-1 mt-1 flex-1 overflow-y-auto pr-1">
          {mode !== 'origin' && (<><Sub right="jiwa">Datang dari</Sub>{ins.map((r) => <BarRow key={r.key} label={r.label} text={nf(r.v)} frac={r.v / mI} onClick={() => setSel(r.key)} />)}</>)}
          {mode !== 'dest' && (<><Sub right="jiwa">Pergi ke</Sub>{outs.map((r) => <BarRow key={r.key} label={r.label} text={nf(r.v)} frac={r.v / mO} onClick={() => setSel(r.key)} />)}</>)}
          <Sub>Jenis kelamin (masuk)</Sub>
          <BarRow label="Laki-laki" text={`${nf(s.mL)} · ${pc(s.mL / (s.mL + s.mP), 0)}`} frac={s.mL / Math.max(s.mL, s.mP)} />
          <BarRow label="Perempuan" text={`${nf(s.mP)} · ${pc(s.mP / (s.mL + s.mP), 0)}`} frac={s.mP / Math.max(s.mL, s.mP)} />
        </div>
        <button onClick={() => open(sel)} className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-white py-2.5 text-[13px] font-bold text-navy-900 transition hover:bg-navy-100">
          Jelajahi {s.name} <ArrowRight size={15} />
        </button>
      </Card>
    </motion.div>
  )
}
