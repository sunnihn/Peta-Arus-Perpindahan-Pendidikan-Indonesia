// Province-level migration model (BPS Long Form SP2020, migrasi risen ≈2017→2022). null stays null.
import raw from './data.json'
import geo from './prov.geo.json'
import { geoMercator, geoPath } from 'd3-geo'

const ALIAS = { bangkabelitung: 'kepulauanbangkabelitung', irianjayabarat: 'papuabarat', jakartaraya: 'dkijakarta', yogyakarta: 'diyogyakarta' }
export const norm = (s) => {
  const k = String(s || '').toLowerCase().replace(/[^a-z]/g, '')
  return ALIAS[k] || k
}
const pretty = (s) => s.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()).replace(/^Dki /, 'DKI ').replace(/^Di /, 'DI ')

export const W = 1000
export const H = 460
const projection = geoMercator().fitExtent([[10, 10], [W - 10, H - 10]], geo)
const path = geoPath(projection)
export const feats = geo.features.map((f) => ({ key: norm(f.properties.name), d: path(f), c: path.centroid(f), b: path.bounds(f) }))
export const featBy = Object.fromEntries(feats.map((f) => [f.key, f]))

export const prov = raw.ind.map((p) => ({
  key: norm(p.Provinsi),
  name: pretty(p.Provinsi),
  in: p['% migran masuk risen'],
  out: p['% migran keluar risen'],
  net: p['% migran neto risen'],
  pop: p['Pop 5+ L+P'],
  mL: p['Migran L'],
  mP: p['Migran P'],
  mig: p['Migran L+P'],
}))
export const provBy = Object.fromEntries(prov.map((p) => [p.key, p]))
export const nameOf = (k) => provBy[k]?.name ?? k
export const od = raw.od.map(([dest, origin, v, kind]) => ({ dest: norm(dest), origin: norm(origin), v, kind }))

export const METRICS = [
  { id: 'in', label: 'Masuk', unit: '% penduduk 5+', fmt: 'pct' },
  { id: 'out', label: 'Keluar', unit: '% penduduk 5+', fmt: 'pct' },
  { id: 'net', label: 'Neto', unit: '% penduduk 5+', fmt: 'pcts' },
  { id: 'mig', label: 'Jumlah', unit: 'jiwa migran masuk', fmt: 'int' },
]
export const fmt = (v, t) => {
  if (v == null) return '—'
  if (t === 'int') return Math.round(v).toLocaleString('id-ID')
  const s = (Math.abs(v) * 100).toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  if (t === 'pcts') return `${v > 0 ? '+' : v < 0 ? '−' : ''}${s}%`
  return `${s}%`
}
export const rankOf = (id) => {
  const list = prov.filter((p) => p[id] != null).sort((a, b) => b[id] - a[id])
  return Object.fromEntries(list.map((p, i) => [p.key, i + 1]))
}

// Detail lists for a province. share = value / total of that group.
export function detail(key, tab) {
  const inn = od.filter((r) => r.dest === key && r.kind === 'Antar provinsi')
  const abroad = od.find((r) => r.dest === key && r.kind === 'Dari luar negeri')
  const within = od.find((r) => r.dest === key && r.kind.startsWith('Dalam'))
  const outt = od.filter((r) => r.origin === key && r.kind === 'Antar provinsi')
  const pack = (rows) => {
    const tot = rows.reduce((s, r) => s + r.v, 0)
    return rows.sort((a, b) => b.v - a.v).map((r) => ({ ...r, share: tot ? r.v / tot : 0 }))
  }
  if (tab === 'asal') return pack([...inn.map((r) => ({ label: nameOf(r.origin), v: r.v })), ...(abroad ? [{ label: 'Luar Negeri', v: abroad.v }] : [])]).slice(0, 8)
  if (tab === 'tujuan') return pack(outt.map((r) => ({ label: nameOf(r.dest), v: r.v }))).slice(0, 8)
  return pack([
    ...(within ? [{ label: 'Pindah dalam provinsi', v: within.v }] : []),
    { label: 'Dari provinsi lain', v: inn.reduce((s, r) => s + r.v, 0) },
    ...(abroad ? [{ label: 'Dari luar negeri', v: abroad.v }] : []),
  ])
}
