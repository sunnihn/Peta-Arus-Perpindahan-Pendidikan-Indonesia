import { Card } from './ui'

export default function Legend() {
  return (
    <Card className="w-[280px] px-3.5 py-3 text-[11px] text-navy-100">
      <div className="mb-2 text-[10.5px] font-semibold uppercase tracking-[0.16em] text-navy-300">Legenda</div>
      <div className="space-y-2.5">
        <div>
          <div className="h-2 rounded-full" style={{ background: 'linear-gradient(90deg,#123a73,#4696eb)' }} />
          <div className="mt-0.5 flex justify-between text-navy-300"><span>kecil</span><span>besar · warna wilayah</span></div>
        </div>
        <div className="flex items-center gap-3">
          <svg width="64" height="18" viewBox="0 0 64 18"><path d="M2 14 Q32 4 62 14" stroke="#9fd3ff" strokeWidth="1" fill="none" /><path d="M2 9 Q32 -1 62 9" stroke="#fff" strokeWidth="3" fill="none" opacity=".85" /></svg>
          <span>tebal &amp; terang = arus besar</span>
        </div>
        <div className="flex items-center gap-3">
          <svg width="64" height="18" viewBox="0 0 64 18"><path d="M2 14 Q32 2 52 9" stroke="#9fd3ff" strokeWidth="1.5" fill="none" /><path d="M62 10 L50 5 L52 9 L50 14 Z" fill="#fff" /></svg>
          <span>panah = asal → tujuan</span>
        </div>
        <div className="flex items-center gap-3">
          <svg width="64" height="20" viewBox="0 0 64 20"><circle cx="12" cy="10" r="7" fill="#fff" opacity=".9" /><circle cx="12" cy="10" r="9.5" fill="none" stroke="#9fd3ff" strokeWidth="1.5" /><circle cx="42" cy="10" r="5" fill="rgba(7,27,53,.55)" stroke="#fff" strokeWidth="2" /></svg>
          <span>titik = nilai indikator<br /><span className="text-navy-300">cincin = terpilih · hitam = neto negatif</span></span>
        </div>
      </div>
    </Card>
  )
}
