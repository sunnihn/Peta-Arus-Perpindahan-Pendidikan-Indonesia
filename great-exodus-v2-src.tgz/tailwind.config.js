/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Poppins', 'system-ui', 'sans-serif'] },
      colors: {
        navy: { 950: '#071B35', 900: '#0B2342', 800: '#12365C', 700: '#174A7E', 500: '#3974A9', 300: '#86A9CB', 100: '#DCE8F3', 50: '#F1F6FB' },
      },
      backgroundImage: {
        'hero-grad': 'linear-gradient(160deg,#071B35 0%,#0B2342 45%,#174A7E 100%)',
        'light-grad': 'linear-gradient(180deg,#FFFFFF 0%,#F1F6FB 60%,#DCE8F3 100%)',
        'blue-grad': 'linear-gradient(135deg,#174A7E 0%,#3974A9 100%)',
      },
      boxShadow: { card: '0 10px 30px -12px rgba(7,27,53,.25)', glow: '0 0 0 1px rgba(134,169,203,.35), 0 20px 50px -20px rgba(57,116,169,.6)' },
    },
  },
  plugins: [],
}
